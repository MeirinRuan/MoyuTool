
package.path= MyLua_GetBaseLuaPath().."\\?.lua;"..package.path

require "CommonFunc"

